import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Types
interface Faculty {
  id: string;
  name: string;
  expertise_course_codes: string[];
}

interface Course {
  id: string;
  course_code: string;
  course_name: string;
  credits: number;
  required_room_type: string;
}

interface StudentGroup {
  id: string;
  group_name: string;
  enrolled_course_codes: string[];
}

interface Room {
  id: string;
  room_number: string;
  capacity: number;
  room_type: string;
}

interface TimeSlot {
  id: string;
  day_of_week: string;
  start_time: string;
  end_time: string;
}

interface Assignment {
  course_id: string;
  course_code: string;
  course_name: string;
  faculty_id: string;
  faculty_name: string;
  room_id: string;
  room_number: string;
  time_slot_id: string;
  day: string;
  time: string;
}

// Backtracking constraint satisfaction solver
class TimetableSolver {
  private faculty: Faculty[];
  private courses: Course[];
  private studentGroups: StudentGroup[];
  private rooms: Room[];
  private timeSlots: TimeSlot[];
  private assignments: Assignment[];
  private facultySchedule: Map<string, Set<string>>; // faculty_id -> set of time_slot_ids
  private roomSchedule: Map<string, Set<string>>; // room_id -> set of time_slot_ids
  private groupSchedule: Map<string, Set<string>>; // group_name -> set of time_slot_ids

  constructor(
    faculty: Faculty[],
    courses: Course[],
    studentGroups: StudentGroup[],
    rooms: Room[],
    timeSlots: TimeSlot[]
  ) {
    this.faculty = faculty;
    this.courses = courses;
    this.studentGroups = studentGroups;
    this.rooms = rooms;
    this.timeSlots = timeSlots;
    this.assignments = [];
    this.facultySchedule = new Map();
    this.roomSchedule = new Map();
    this.groupSchedule = new Map();
  }

  solve(): Assignment[] | null {
    console.log(`Starting solver with ${this.courses.length} courses`);
    
    if (this.backtrack(0)) {
      console.log(`Solution found with ${this.assignments.length} assignments`);
      return this.assignments;
    }
    
    console.log('No solution found');
    return null;
  }

  private backtrack(courseIndex: number): boolean {
    // Base case: all courses assigned
    if (courseIndex >= this.courses.length) {
      return true;
    }

    const course = this.courses[courseIndex];
    console.log(`Attempting to schedule: ${course.course_code}`);

    // Try all possible combinations of faculty, room, and time slot
    for (const faculty of this.faculty) {
      if (!this.canFacultyTeach(faculty, course)) {
        continue;
      }

      for (const room of this.rooms) {
        if (!this.isRoomCompatible(room, course)) {
          continue;
        }

        for (const timeSlot of this.timeSlots) {
          if (this.canAssign(course, faculty, room, timeSlot)) {
            // Make assignment
            this.assign(course, faculty, room, timeSlot);

            // Recursively try to assign next course
            if (this.backtrack(courseIndex + 1)) {
              return true;
            }

            // Backtrack: undo assignment
            this.unassign(course, faculty, room, timeSlot);
          }
        }
      }
    }

    return false;
  }

  private canFacultyTeach(faculty: Faculty, course: Course): boolean {
    return faculty.expertise_course_codes.includes(course.course_code);
  }

  private isRoomCompatible(room: Room, course: Course): boolean {
    return room.room_type === course.required_room_type;
  }

  private canAssign(
    course: Course,
    faculty: Faculty,
    room: Room,
    timeSlot: TimeSlot
  ): boolean {
    // Check faculty clash
    const facultySlots = this.facultySchedule.get(faculty.id) || new Set();
    if (facultySlots.has(timeSlot.id)) {
      return false;
    }

    // Check room clash
    const roomSlots = this.roomSchedule.get(room.id) || new Set();
    if (roomSlots.has(timeSlot.id)) {
      return false;
    }

    // Check student group clashes
    const affectedGroups = this.studentGroups.filter(group =>
      group.enrolled_course_codes.includes(course.course_code)
    );

    for (const group of affectedGroups) {
      const groupSlots = this.groupSchedule.get(group.group_name) || new Set();
      if (groupSlots.has(timeSlot.id)) {
        return false;
      }
    }

    return true;
  }

  private assign(
    course: Course,
    faculty: Faculty,
    room: Room,
    timeSlot: TimeSlot
  ): void {
    // Add to assignments
    this.assignments.push({
      course_id: course.id,
      course_code: course.course_code,
      course_name: course.course_name,
      faculty_id: faculty.id,
      faculty_name: faculty.name,
      room_id: room.id,
      room_number: room.room_number,
      time_slot_id: timeSlot.id,
      day: timeSlot.day_of_week,
      time: `${timeSlot.start_time} - ${timeSlot.end_time}`,
    });

    // Update schedules
    if (!this.facultySchedule.has(faculty.id)) {
      this.facultySchedule.set(faculty.id, new Set());
    }
    this.facultySchedule.get(faculty.id)!.add(timeSlot.id);

    if (!this.roomSchedule.has(room.id)) {
      this.roomSchedule.set(room.id, new Set());
    }
    this.roomSchedule.get(room.id)!.add(timeSlot.id);

    const affectedGroups = this.studentGroups.filter(group =>
      group.enrolled_course_codes.includes(course.course_code)
    );

    for (const group of affectedGroups) {
      if (!this.groupSchedule.has(group.group_name)) {
        this.groupSchedule.set(group.group_name, new Set());
      }
      this.groupSchedule.get(group.group_name)!.add(timeSlot.id);
    }
  }

  private unassign(
    course: Course,
    faculty: Faculty,
    room: Room,
    timeSlot: TimeSlot
  ): void {
    // Remove from assignments
    this.assignments.pop();

    // Update schedules
    this.facultySchedule.get(faculty.id)?.delete(timeSlot.id);
    this.roomSchedule.get(room.id)?.delete(timeSlot.id);

    const affectedGroups = this.studentGroups.filter(group =>
      group.enrolled_course_codes.includes(course.course_code)
    );

    for (const group of affectedGroups) {
      this.groupSchedule.get(group.group_name)?.delete(timeSlot.id);
    }
  }
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Generate timetable function invoked');

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );

    // Fetch all data from database
    console.log('Fetching data from database...');

    const [facultyRes, coursesRes, groupsRes, roomsRes, slotsRes] = await Promise.all([
      supabaseClient.from('faculty').select('*'),
      supabaseClient.from('courses').select('*'),
      supabaseClient.from('student_groups').select('*'),
      supabaseClient.from('rooms').select('*'),
      supabaseClient.from('time_slots').select('*').order('day_of_week').order('start_time'),
    ]);

    if (facultyRes.error) throw facultyRes.error;
    if (coursesRes.error) throw coursesRes.error;
    if (groupsRes.error) throw groupsRes.error;
    if (roomsRes.error) throw roomsRes.error;
    if (slotsRes.error) throw slotsRes.error;

    const faculty = facultyRes.data as Faculty[];
    const courses = coursesRes.data as Course[];
    const studentGroups = groupsRes.data as StudentGroup[];
    const rooms = roomsRes.data as Room[];
    const timeSlots = slotsRes.data as TimeSlot[];

    console.log(`Loaded: ${faculty.length} faculty, ${courses.length} courses, ${studentGroups.length} groups, ${rooms.length} rooms, ${timeSlots.length} time slots`);

    // Create solver and run
    const solver = new TimetableSolver(faculty, courses, studentGroups, rooms, timeSlots);
    const solution = solver.solve();

    if (!solution) {
      return new Response(
        JSON.stringify({
          success: false,
          error: 'No valid timetable could be generated with the current constraints. Try adjusting the number of courses, rooms, or time slots.',
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      );
    }

    // Clear existing timetable entries
    await supabaseClient.from('timetable_entries').delete().neq('id', '00000000-0000-0000-0000-000000000000');

    // Save solution to database
    const entriesToInsert = solution.map(assignment => ({
      course_id: assignment.course_id,
      faculty_id: assignment.faculty_id,
      room_id: assignment.room_id,
      time_slot_id: assignment.time_slot_id,
    }));

    const { error: insertError } = await supabaseClient
      .from('timetable_entries')
      .insert(entriesToInsert);

    if (insertError) {
      console.error('Error inserting timetable entries:', insertError);
    }

    console.log('Timetable generation completed successfully');

    return new Response(
      JSON.stringify({
        success: true,
        timetable: solution,
        stats: {
          courses_scheduled: solution.length,
          total_courses: courses.length,
        },
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Error in generate-timetable function:', error);
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'An unknown error occurred',
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});
