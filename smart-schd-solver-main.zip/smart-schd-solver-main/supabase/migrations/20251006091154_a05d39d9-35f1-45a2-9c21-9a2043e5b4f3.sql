-- Create app_role enum
CREATE TYPE public.app_role AS ENUM ('admin', 'faculty', 'student');

-- Create profiles table linked to auth.users
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  role app_role NOT NULL DEFAULT 'student',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create user_roles table for secure role checking
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  UNIQUE (user_id, role)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Function to handle new user signups
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'User'),
    COALESCE((NEW.raw_user_meta_data->>'role')::app_role, 'student')
  );
  
  -- Also add role to user_roles table
  INSERT INTO public.user_roles (user_id, role)
  VALUES (
    NEW.id,
    COALESCE((NEW.raw_user_meta_data->>'role')::app_role, 'student')
  );
  
  RETURN NEW;
END;
$$;

-- Trigger for new user creation
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Add user_id to faculty table
ALTER TABLE public.faculty ADD COLUMN user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL;

-- Add user_id to student_groups table
ALTER TABLE public.student_groups ADD COLUMN user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL;

-- RLS Policies for profiles
CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles"
  ON public.profiles FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all profiles"
  ON public.profiles FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert profiles"
  ON public.profiles FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete profiles"
  ON public.profiles FOR DELETE
  USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for user_roles
CREATE POLICY "Users can view their own roles"
  ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all roles"
  ON public.user_roles FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- Update RLS policies for courses (admin can manage, others can view)
DROP POLICY IF EXISTS "Anyone can view courses" ON public.courses;

CREATE POLICY "Authenticated users can view courses"
  ON public.courses FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert courses"
  ON public.courses FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update courses"
  ON public.courses FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete courses"
  ON public.courses FOR DELETE
  USING (public.has_role(auth.uid(), 'admin'));

-- Update RLS policies for faculty
DROP POLICY IF EXISTS "Anyone can view faculty" ON public.faculty;

CREATE POLICY "Authenticated users can view faculty"
  ON public.faculty FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert faculty"
  ON public.faculty FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update faculty"
  ON public.faculty FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete faculty"
  ON public.faculty FOR DELETE
  USING (public.has_role(auth.uid(), 'admin'));

-- Update RLS policies for student_groups
DROP POLICY IF EXISTS "Anyone can view student groups" ON public.student_groups;

CREATE POLICY "Authenticated users can view student groups"
  ON public.student_groups FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert student groups"
  ON public.student_groups FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update student groups"
  ON public.student_groups FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete student groups"
  ON public.student_groups FOR DELETE
  USING (public.has_role(auth.uid(), 'admin'));

-- Update RLS policies for rooms
DROP POLICY IF EXISTS "Anyone can view rooms" ON public.rooms;

CREATE POLICY "Authenticated users can view rooms"
  ON public.rooms FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert rooms"
  ON public.rooms FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update rooms"
  ON public.rooms FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete rooms"
  ON public.rooms FOR DELETE
  USING (public.has_role(auth.uid(), 'admin'));

-- Update RLS policies for time_slots
DROP POLICY IF EXISTS "Anyone can view time slots" ON public.time_slots;

CREATE POLICY "Authenticated users can view time slots"
  ON public.time_slots FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert time slots"
  ON public.time_slots FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update time slots"
  ON public.time_slots FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete time slots"
  ON public.time_slots FOR DELETE
  USING (public.has_role(auth.uid(), 'admin'));

-- Update RLS policies for timetable_entries
DROP POLICY IF EXISTS "Anyone can view timetable entries" ON public.timetable_entries;

CREATE POLICY "Authenticated users can view timetable entries"
  ON public.timetable_entries FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert timetable entries"
  ON public.timetable_entries FOR INSERT
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update timetable entries"
  ON public.timetable_entries FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete timetable entries"
  ON public.timetable_entries FOR DELETE
  USING (public.has_role(auth.uid(), 'admin'));

-- Insert a default admin user (for testing purposes)
-- Password will need to be set through Supabase Auth UI or signup
-- This just creates the profile and role entries
-- Note: You'll need to create the actual auth.users entry through the signup process