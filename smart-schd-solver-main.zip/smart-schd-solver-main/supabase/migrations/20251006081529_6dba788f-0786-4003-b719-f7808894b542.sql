-- Create faculty table
CREATE TABLE public.faculty (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  expertise_course_codes TEXT[] NOT NULL DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create courses table
CREATE TABLE public.courses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  course_code TEXT NOT NULL UNIQUE,
  course_name TEXT NOT NULL,
  credits INTEGER NOT NULL,
  required_room_type TEXT NOT NULL CHECK (required_room_type IN ('lecture', 'lab')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create student_groups table
CREATE TABLE public.student_groups (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  group_name TEXT NOT NULL UNIQUE,
  enrolled_course_codes TEXT[] NOT NULL DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create rooms table
CREATE TABLE public.rooms (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_number TEXT NOT NULL UNIQUE,
  capacity INTEGER NOT NULL,
  room_type TEXT NOT NULL CHECK (room_type IN ('lecture', 'lab')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create time_slots table
CREATE TABLE public.time_slots (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  day_of_week TEXT NOT NULL CHECK (day_of_week IN ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday')),
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create timetable_entries table (to store generated timetables)
CREATE TABLE public.timetable_entries (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  course_id UUID REFERENCES public.courses(id) ON DELETE CASCADE,
  faculty_id UUID REFERENCES public.faculty(id) ON DELETE CASCADE,
  room_id UUID REFERENCES public.rooms(id) ON DELETE CASCADE,
  time_slot_id UUID REFERENCES public.time_slots(id) ON DELETE CASCADE,
  generated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.faculty ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.time_slots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.timetable_entries ENABLE ROW LEVEL SECURITY;

-- Create policies for public read access (suitable for prototype/hackathon)
CREATE POLICY "Anyone can view faculty" ON public.faculty FOR SELECT USING (true);
CREATE POLICY "Anyone can view courses" ON public.courses FOR SELECT USING (true);
CREATE POLICY "Anyone can view student groups" ON public.student_groups FOR SELECT USING (true);
CREATE POLICY "Anyone can view rooms" ON public.rooms FOR SELECT USING (true);
CREATE POLICY "Anyone can view time slots" ON public.time_slots FOR SELECT USING (true);
CREATE POLICY "Anyone can view timetable entries" ON public.timetable_entries FOR SELECT USING (true);

-- Insert sample faculty data
INSERT INTO public.faculty (name, expertise_course_codes) VALUES
('Dr. Sarah Johnson', ARRAY['CS101', 'CS201', 'CS301']),
('Prof. Michael Chen', ARRAY['CS102', 'CS202']),
('Dr. Emily Rodriguez', ARRAY['MATH101', 'MATH201']),
('Prof. David Kumar', ARRAY['PHY101', 'PHY201']),
('Dr. Lisa Wang', ARRAY['CS103', 'CS203']);

-- Insert sample courses
INSERT INTO public.courses (course_code, course_name, credits, required_room_type) VALUES
('CS101', 'Introduction to Programming', 4, 'lecture'),
('CS102', 'Data Structures', 4, 'lecture'),
('CS103', 'Database Systems', 3, 'lecture'),
('CS201', 'Algorithms', 4, 'lecture'),
('CS202', 'Operating Systems', 3, 'lab'),
('CS203', 'Web Development', 3, 'lab'),
('CS301', 'Machine Learning', 4, 'lecture'),
('MATH101', 'Calculus I', 4, 'lecture'),
('MATH201', 'Linear Algebra', 3, 'lecture'),
('PHY101', 'Physics I', 4, 'lab'),
('PHY201', 'Quantum Mechanics', 3, 'lecture');

-- Insert sample student groups
INSERT INTO public.student_groups (group_name, enrolled_course_codes) VALUES
('CSE-A', ARRAY['CS101', 'MATH101', 'CS102']),
('CSE-B', ARRAY['CS103', 'PHY101', 'MATH101']),
('CSE-C', ARRAY['CS201', 'CS202', 'MATH201']),
('CSE-D', ARRAY['CS203', 'CS301', 'PHY201']);

-- Insert sample rooms
INSERT INTO public.rooms (room_number, capacity, room_type) VALUES
('R101', 60, 'lecture'),
('R102', 60, 'lecture'),
('R103', 40, 'lecture'),
('L201', 30, 'lab'),
('L202', 30, 'lab'),
('L203', 25, 'lab'),
('R104', 50, 'lecture'),
('R105', 45, 'lecture');

-- Insert sample time slots (5 slots per day, 6 days a week)
INSERT INTO public.time_slots (day_of_week, start_time, end_time) VALUES
-- Monday
('Monday', '09:00', '10:00'),
('Monday', '10:00', '11:00'),
('Monday', '11:00', '12:00'),
('Monday', '14:00', '15:00'),
('Monday', '15:00', '16:00'),
-- Tuesday
('Tuesday', '09:00', '10:00'),
('Tuesday', '10:00', '11:00'),
('Tuesday', '11:00', '12:00'),
('Tuesday', '14:00', '15:00'),
('Tuesday', '15:00', '16:00'),
-- Wednesday
('Wednesday', '09:00', '10:00'),
('Wednesday', '10:00', '11:00'),
('Wednesday', '11:00', '12:00'),
('Wednesday', '14:00', '15:00'),
('Wednesday', '15:00', '16:00'),
-- Thursday
('Thursday', '09:00', '10:00'),
('Thursday', '10:00', '11:00'),
('Thursday', '11:00', '12:00'),
('Thursday', '14:00', '15:00'),
('Thursday', '15:00', '16:00'),
-- Friday
('Friday', '09:00', '10:00'),
('Friday', '10:00', '11:00'),
('Friday', '11:00', '12:00'),
('Friday', '14:00', '15:00'),
('Friday', '15:00', '16:00'),
-- Saturday
('Saturday', '09:00', '10:00'),
('Saturday', '10:00', '11:00'),
('Saturday', '11:00', '12:00');