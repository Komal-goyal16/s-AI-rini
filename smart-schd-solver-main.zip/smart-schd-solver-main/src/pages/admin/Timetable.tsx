import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import TimetableGrid from '@/components/TimetableGrid';
import ExportButtons from '@/components/ExportButtons';
import EditEntryDialog from '@/components/EditEntryDialog';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Calendar as CalendarIcon } from 'lucide-react';

export default function AdminTimetable() {
  const [loading, setLoading] = useState(false);
  const [timetableData, setTimetableData] = useState<any>(null);
  const [editMode, setEditMode] = useState(false);
  const [editingEntry, setEditingEntry] = useState<any>(null);
  const [availableFaculty, setAvailableFaculty] = useState<any[]>([]);
  const [availableRooms, setAvailableRooms] = useState<any[]>([]);
  const [availableTimeSlots, setAvailableTimeSlots] = useState<any[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    loadExistingTimetable();
    loadAvailableOptions();
  }, []);

  const loadExistingTimetable = async () => {
    const { data } = await supabase
      .from('timetable_entries')
      .select(`
        *,
        course:courses(*),
        faculty:faculty(*),
        room:rooms(*),
        time_slot:time_slots(*)
      `);

    if (data && data.length > 0) {
      const entries = data.map((entry: any) => ({
        course_code: entry.course.course_code,
        course_name: entry.course.course_name,
        faculty_name: entry.faculty.name,
        room_number: entry.room.room_number,
        day: entry.time_slot.day_of_week,
        time: `${entry.time_slot.start_time} - ${entry.time_slot.end_time}`,
      }));
      setTimetableData(entries);
    }
  };

  const loadAvailableOptions = async () => {
    const [facultyRes, roomsRes, timeSlotsRes] = await Promise.all([
      supabase.from('faculty').select('*'),
      supabase.from('rooms').select('*'),
      supabase.from('time_slots').select('*'),
    ]);

    if (facultyRes.data) setAvailableFaculty(facultyRes.data);
    if (roomsRes.data) setAvailableRooms(roomsRes.data);
    if (timeSlotsRes.data) setAvailableTimeSlots(timeSlotsRes.data);
  };

  const generateTimetable = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-timetable');

      if (error) throw error;

      if (data.error) {
        toast({
          variant: 'destructive',
          title: 'Generation Failed',
          description: data.error,
        });
      } else {
        const entries = data.timetable.map((item: any) => ({
          course_code: item.course.course_code,
          course_name: item.course.course_name,
          faculty_name: item.faculty.name,
          room_number: item.room.room_number,
          day: item.timeSlot.day_of_week,
          time: `${item.timeSlot.start_time} - ${item.timeSlot.end_time}`,
        }));
        setTimetableData(entries);
        toast({
          title: 'Success!',
          description: 'Timetable generated successfully',
        });
      }
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEditEntry = (entry: any) => {
    setEditingEntry(entry);
  };

  const handleSaveEdit = async (updates: {
    oldEntry: any;
    newFacultyId: string;
    newRoomId: string;
    newTimeSlotId: string;
  }) => {
    const { data: course } = await supabase
      .from('courses')
      .select('id')
      .eq('course_code', updates.oldEntry.course_code)
      .single();

    if (course) {
      const { data: existingEntry } = await supabase
        .from('timetable_entries')
        .select('id')
        .eq('course_id', course.id)
        .single();

      if (existingEntry) {
        await supabase
          .from('timetable_entries')
          .update({
            faculty_id: updates.newFacultyId,
            room_id: updates.newRoomId,
            time_slot_id: updates.newTimeSlotId,
          })
          .eq('id', existingEntry.id);
      }

      await loadExistingTimetable();
      toast({
        title: 'Updated',
        description: 'Timetable entry updated successfully',
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Timetable Management</h1>
          <p className="text-muted-foreground">Generate and manage the master timetable</p>
        </div>
        <div className="flex gap-2">
          {timetableData && (
            <>
              <Button
                variant="outline"
                onClick={() => setEditMode(!editMode)}
              >
                {editMode ? 'View Mode' : 'Edit Mode'}
              </Button>
              <ExportButtons entries={timetableData} />
            </>
          )}
          <Button onClick={generateTimetable} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <CalendarIcon className="mr-2 h-4 w-4" />
                Generate Timetable
              </>
            )}
          </Button>
        </div>
      </div>

      {timetableData ? (
        <Card>
          <CardHeader>
            <CardTitle>Generated Timetable</CardTitle>
            <CardDescription>
              {editMode ? 'Click on any entry to edit' : 'View the complete timetable'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <TimetableGrid
              entries={timetableData}
              editable={editMode}
              onEditEntry={handleEditEntry}
            />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <CalendarIcon className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No Timetable Generated</h3>
            <p className="text-muted-foreground text-center mb-4">
              Click the "Generate Timetable" button to create a new schedule
            </p>
          </CardContent>
        </Card>
      )}

      <EditEntryDialog
        open={!!editingEntry}
        onOpenChange={(open) => !open && setEditingEntry(null)}
        entry={editingEntry}
        onSave={handleSaveEdit}
        availableFaculty={availableFaculty}
        availableRooms={availableRooms}
        availableTimeSlots={availableTimeSlots}
      />
    </div>
  );
}
