import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import StatsCard from '@/components/StatsCard';
import { BookOpen, Users, UsersRound, DoorOpen, Clock, Calendar } from 'lucide-react';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    courses: 0,
    faculty: 0,
    studentGroups: 0,
    rooms: 0,
    timeSlots: 0,
    timetableEntries: 0,
  });

  useEffect(() => {
    const fetchStats = async () => {
      const [courses, faculty, studentGroups, rooms, timeSlots, timetableEntries] = await Promise.all([
        supabase.from('courses').select('*', { count: 'exact', head: true }),
        supabase.from('faculty').select('*', { count: 'exact', head: true }),
        supabase.from('student_groups').select('*', { count: 'exact', head: true }),
        supabase.from('rooms').select('*', { count: 'exact', head: true }),
        supabase.from('time_slots').select('*', { count: 'exact', head: true }),
        supabase.from('timetable_entries').select('*', { count: 'exact', head: true }),
      ]);

      setStats({
        courses: courses.count || 0,
        faculty: faculty.count || 0,
        studentGroups: studentGroups.count || 0,
        rooms: rooms.count || 0,
        timeSlots: timeSlots.count || 0,
        timetableEntries: timetableEntries.count || 0,
      });
    };

    fetchStats();
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground">Welcome to the timetable management system</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <StatsCard
          title="Courses"
          value={stats.courses}
          icon={BookOpen}
        />
        <StatsCard
          title="Faculty Members"
          value={stats.faculty}
          icon={Users}
        />
        <StatsCard
          title="Student Groups"
          value={stats.studentGroups}
          icon={UsersRound}
        />
        <StatsCard
          title="Rooms"
          value={stats.rooms}
          icon={DoorOpen}
        />
        <StatsCard
          title="Time Slots"
          value={stats.timeSlots}
          icon={Clock}
        />
        <StatsCard
          title="Scheduled Classes"
          value={stats.timetableEntries}
          icon={Calendar}
        />
      </div>
    </div>
  );
}
