import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, Calendar, Users, BookOpen, Clock, Edit3 } from "lucide-react";
import TimetableGrid from "@/components/TimetableGrid";
import StatsCard from "@/components/StatsCard";
import ExportButtons from "@/components/ExportButtons";
import EditEntryDialog from "@/components/EditEntryDialog";
import { Badge } from "@/components/ui/badge";

interface TimetableEntry {
  course_code: string;
  course_name: string;
  faculty_name: string;
  room_number: string;
  day: string;
  time: string;
}

const Index = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [timetable, setTimetable] = useState<TimetableEntry[] | null>(null);
  const [stats, setStats] = useState<{ courses_scheduled: number; total_courses: number } | null>(null);
  const [editMode, setEditMode] = useState(false);
  const [editingEntry, setEditingEntry] = useState<TimetableEntry | null>(null);
  const [availableFaculty, setAvailableFaculty] = useState<any[]>([]);
  const [availableRooms, setAvailableRooms] = useState<any[]>([]);
  const [availableTimeSlots, setAvailableTimeSlots] = useState<any[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    loadResources();
  }, []);

  const loadResources = async () => {
    try {
      const [facultyRes, roomsRes, slotsRes] = await Promise.all([
        supabase.from('faculty').select('*'),
        supabase.from('rooms').select('*'),
        supabase.from('time_slots').select('*').order('day_of_week').order('start_time'),
      ]);

      if (facultyRes.data) setAvailableFaculty(facultyRes.data);
      if (roomsRes.data) setAvailableRooms(roomsRes.data);
      if (slotsRes.data) setAvailableTimeSlots(slotsRes.data);
    } catch (error) {
      console.error('Error loading resources:', error);
    }
  };

  const generateTimetable = async () => {
    setIsGenerating(true);
    
    try {
      console.log('Invoking generate-timetable function...');
      
      const { data, error } = await supabase.functions.invoke('generate-timetable', {
        body: {},
      });

      if (error) {
        console.error('Function invocation error:', error);
        throw error;
      }

      console.log('Function response:', data);

      if (!data.success) {
        toast({
          title: "Generation Failed",
          description: data.error || "Could not generate a valid timetable",
          variant: "destructive",
        });
        return;
      }

      setTimetable(data.timetable);
      setStats(data.stats);

      toast({
        title: "Success!",
        description: `Generated timetable with ${data.stats.courses_scheduled} courses scheduled`,
      });
    } catch (error) {
      console.error('Error generating timetable:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to generate timetable",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleEditEntry = (entry: TimetableEntry) => {
    setEditingEntry(entry);
  };

  const handleSaveEdit = async (updates: {
    oldEntry: TimetableEntry;
    newFacultyId: string;
    newRoomId: string;
    newTimeSlotId: string;
  }) => {
    try {
      // Find the course ID
      const { data: courseData } = await supabase
        .from('courses')
        .select('id')
        .eq('course_code', updates.oldEntry.course_code)
        .single();

      if (!courseData) throw new Error('Course not found');

      // Find existing timetable entry
      const oldTimeSlot = availableTimeSlots.find(
        ts => ts.day_of_week === updates.oldEntry.day && 
        `${ts.start_time} - ${ts.end_time}` === updates.oldEntry.time
      );

      // Delete old entry and insert new one
      await supabase
        .from('timetable_entries')
        .delete()
        .eq('course_id', courseData.id)
        .eq('time_slot_id', oldTimeSlot?.id);

      await supabase
        .from('timetable_entries')
        .insert({
          course_id: courseData.id,
          faculty_id: updates.newFacultyId,
          room_id: updates.newRoomId,
          time_slot_id: updates.newTimeSlotId,
        });

      // Refresh timetable
      const { data, error } = await supabase.functions.invoke('generate-timetable', {
        body: {},
      });

      if (!error && data.success) {
        setTimetable(data.timetable);
        toast({
          title: "Updated Successfully",
          description: "Class schedule has been modified",
        });
      }
    } catch (error) {
      console.error('Error updating entry:', error);
      toast({
        title: "Error",
        description: "Failed to update the schedule",
        variant: "destructive",
      });
    }
  };


  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary/90 to-accent py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center space-y-6">
            <h1 className="text-4xl md:text-6xl font-bold text-white">
              NEP 2020 Timetable Generator
            </h1>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              AI-powered constraint satisfaction algorithm for conflict-free class scheduling
            </p>
            <Button
              onClick={generateTimetable}
              disabled={isGenerating}
              size="lg"
              variant="hero"
              className="mt-8"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Generating Schedule...
                </>
              ) : (
                <>
                  <Calendar className="mr-2 h-5 w-5" />
                  Generate Timetable
                </>
              )}
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      {stats && (
        <section className="py-12 px-4 bg-secondary/30">
          <div className="container mx-auto max-w-6xl">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <StatsCard
                title="Courses Scheduled"
                value={stats.courses_scheduled}
                icon={BookOpen}
                description="Successfully allocated"
              />
              <StatsCard
                title="Total Courses"
                value={stats.total_courses}
                icon={Calendar}
                description="In the system"
              />
              <StatsCard
                title="Success Rate"
                value={`${Math.round((stats.courses_scheduled / stats.total_courses) * 100)}%`}
                icon={Clock}
                description="Scheduling efficiency"
              />
              <StatsCard
                title="Algorithm"
                value="Backtrack"
                icon={Users}
                description="Constraint satisfaction"
              />
            </div>
          </div>
        </section>
      )}

      {/* Timetable Display */}
      {timetable && timetable.length > 0 && (
        <section className="py-12 px-4">
          <div className="container mx-auto max-w-6xl">
            <Card className="shadow-xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-2xl">Generated Class Timetable</CardTitle>
                    <CardDescription>
                      Conflict-free schedule generated using AI-based constraint satisfaction
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button
                      variant={editMode ? "default" : "outline"}
                      onClick={() => setEditMode(!editMode)}
                      className="gap-2"
                    >
                      <Edit3 className="h-4 w-4" />
                      {editMode ? "Exit Edit Mode" : "Edit Mode"}
                    </Button>
                    <ExportButtons entries={timetable} />
                  </div>
                </div>
                {editMode && (
                  <Badge variant="secondary" className="w-fit mt-2">
                    Click on any class to modify its assignment
                  </Badge>
                )}
              </CardHeader>
              <CardContent>
                <TimetableGrid 
                  entries={timetable} 
                  editable={editMode}
                  onEditEntry={handleEditEntry}
                />
              </CardContent>
            </Card>

            <EditEntryDialog
              open={!!editingEntry}
              onOpenChange={(open) => !open && setEditingEntry(null)}
              entry={editingEntry}
              availableFaculty={availableFaculty}
              availableRooms={availableRooms}
              availableTimeSlots={availableTimeSlots}
              onSave={handleSaveEdit}
            />
          </div>
        </section>
      )}

      {/* Info Section */}
      {!timetable && (
        <section className="py-12 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="grid md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-primary" />
                    Smart Constraints
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  Ensures no faculty, room, or student group conflicts across time slots
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    Faculty Expertise
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  Matches courses with qualified faculty based on their expertise areas
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-primary" />
                    Room Allocation
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  Assigns appropriate room types (lecture halls or labs) for each course
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};

export default Index;
