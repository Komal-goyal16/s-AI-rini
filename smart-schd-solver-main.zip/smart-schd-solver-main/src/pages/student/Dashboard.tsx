import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import TimetableGrid from '@/components/TimetableGrid';
import { Calendar } from 'lucide-react';

export default function StudentDashboard() {
  const { user } = useAuth();
  const [groupSchedule, setGroupSchedule] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchGroupSchedule();
    }
  }, [user]);

  const fetchGroupSchedule = async () => {
    try {
      const { data: studentGroup, error } = await supabase
        .from('student_groups')
        .select('id, group_name, enrolled_course_codes')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (error) {
        console.error('Error fetching student group:', error);
        setLoading(false);
        return;
      }

      if (!studentGroup) {
        console.log('No student group found for user');
        setLoading(false);
        return;
      }

      const { data: courses } = await supabase
        .from('courses')
        .select('id')
        .in('course_code', studentGroup.enrolled_course_codes);

      if (courses) {
        const courseIds = courses.map(c => c.id);
        
        const { data: entries } = await supabase
          .from('timetable_entries')
          .select(`
            *,
            course:courses(*),
            faculty:faculty(*),
            room:rooms(*),
            time_slot:time_slots(*)
          `)
          .in('course_id', courseIds);

        if (entries && entries.length > 0) {
          const formattedEntries = entries.map((entry: any) => ({
            course_code: entry.course.course_code,
            course_name: entry.course.course_name,
            faculty_name: entry.faculty.name,
            room_number: entry.room.room_number,
            day: entry.time_slot.day_of_week,
            time: `${entry.time_slot.start_time} - ${entry.time_slot.end_time}`,
          }));
          setGroupSchedule(formattedEntries);
        }
      }
    } catch (error) {
      console.error('Error in fetchGroupSchedule:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">My Timetable</h1>
        <p className="text-muted-foreground">View your class schedule</p>
      </div>

      {loading ? (
        <Card>
          <CardContent className="py-16 text-center">
            <p className="text-muted-foreground">Loading your timetable...</p>
          </CardContent>
        </Card>
      ) : groupSchedule ? (
        <Card>
          <CardHeader>
            <CardTitle>Weekly Class Schedule</CardTitle>
            <CardDescription>Your classes for this week</CardDescription>
          </CardHeader>
          <CardContent>
            <TimetableGrid entries={groupSchedule} />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Calendar className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No Timetable Available</h3>
            <p className="text-muted-foreground text-center max-w-md">
              You are not assigned to any student group yet. 
              Please contact your administrator to be added to a student group.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
