import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import TimetableGrid from '@/components/TimetableGrid';
import { Calendar, BookOpen } from 'lucide-react';

export default function FacultyDashboard() {
  const { user } = useAuth();
  const [mySchedule, setMySchedule] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchMySchedule();
    }
  }, [user]);

  const fetchMySchedule = async () => {
    try {
      const { data: facultyData, error } = await supabase
        .from('faculty')
        .select('id')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (error) {
        console.error('Error fetching faculty:', error);
        setLoading(false);
        return;
      }

      if (!facultyData) {
        console.log('No faculty record found for user');
        setLoading(false);
        return;
      }

      const { data: entries } = await supabase
        .from('timetable_entries')
        .select(`
          *,
          course:courses(*),
          faculty:faculty(*),
          room:rooms(*),
          time_slot:time_slots(*)
        `)
        .eq('faculty_id', facultyData.id);

      if (entries && entries.length > 0) {
        const formattedEntries = entries.map((entry: any) => ({
          course_code: entry.course.course_code,
          course_name: entry.course.course_name,
          faculty_name: entry.faculty.name,
          room_number: entry.room.room_number,
          day: entry.time_slot.day_of_week,
          time: `${entry.time_slot.start_time} - ${entry.time_slot.end_time}`,
        }));
        setMySchedule(formattedEntries);
      }
    } catch (error) {
      console.error('Error in fetchMySchedule:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">My Schedule</h1>
        <p className="text-muted-foreground">View your teaching schedule</p>
      </div>

      {loading ? (
        <Card>
          <CardContent className="py-16 text-center">
            <p className="text-muted-foreground">Loading your schedule...</p>
          </CardContent>
        </Card>
      ) : mySchedule ? (
        <Card>
          <CardHeader>
            <CardTitle>Weekly Teaching Schedule</CardTitle>
            <CardDescription>Your assigned classes for this week</CardDescription>
          </CardHeader>
          <CardContent>
            <TimetableGrid entries={mySchedule} />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Calendar className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No Classes Assigned</h3>
            <p className="text-muted-foreground text-center max-w-md">
              You don't have any classes assigned in the current timetable. 
              Please contact your administrator to set up your faculty profile and course assignments.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
