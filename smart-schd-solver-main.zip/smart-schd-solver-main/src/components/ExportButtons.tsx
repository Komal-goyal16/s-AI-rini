import { Button } from "@/components/ui/button";
import { Download, FileSpreadsheet } from "lucide-react";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";

interface TimetableEntry {
  course_code: string;
  course_name: string;
  faculty_name: string;
  room_number: string;
  day: string;
  time: string;
}

interface ExportButtonsProps {
  entries: TimetableEntry[];
}

const ExportButtons = ({ entries }: ExportButtonsProps) => {
  const exportToPDF = () => {
    const doc = new jsPDF('l', 'mm', 'a4');
    
    // Add title
    doc.setFontSize(18);
    doc.text('NEP 2020 Academic Timetable', 14, 15);
    doc.setFontSize(10);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 22);

    // Prepare data for the table
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const times = Array.from(new Set(entries.map(e => e.time))).sort();

    // Create entry map
    const entryMap = new Map<string, TimetableEntry>();
    entries.forEach(entry => {
      const key = `${entry.day}-${entry.time}`;
      entryMap.set(key, entry);
    });

    // Build table data
    const tableData: string[][] = [];
    
    times.forEach(time => {
      const row = [time];
      days.forEach(day => {
        const entry = entryMap.get(`${day}-${time}`);
        if (entry) {
          row.push(`${entry.course_code}\n${entry.course_name}\n${entry.faculty_name}\n${entry.room_number}`);
        } else {
          row.push('Free');
        }
      });
      tableData.push(row);
    });

    // Generate table
    autoTable(doc, {
      head: [['Time', ...days]],
      body: tableData,
      startY: 28,
      theme: 'grid',
      styles: {
        fontSize: 8,
        cellPadding: 3,
        overflow: 'linebreak',
      },
      headStyles: {
        fillColor: [67, 56, 202], // primary color
        textColor: 255,
        fontStyle: 'bold',
      },
      columnStyles: {
        0: { fontStyle: 'bold', fillColor: [240, 240, 250] },
      },
    });

    doc.save('timetable.pdf');
  };

  const exportToExcel = () => {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const times = Array.from(new Set(entries.map(e => e.time))).sort();

    // Create entry map
    const entryMap = new Map<string, TimetableEntry>();
    entries.forEach(entry => {
      const key = `${entry.day}-${entry.time}`;
      entryMap.set(key, entry);
    });

    // Build worksheet data
    const wsData: (string | number)[][] = [
      ['NEP 2020 Academic Timetable'],
      [`Generated on: ${new Date().toLocaleDateString()}`],
      [],
      ['Time', ...days],
    ];

    times.forEach(time => {
      const row: string[] = [time];
      days.forEach(day => {
        const entry = entryMap.get(`${day}-${time}`);
        if (entry) {
          row.push(`${entry.course_code} - ${entry.course_name}\n${entry.faculty_name} | ${entry.room_number}`);
        } else {
          row.push('Free');
        }
      });
      wsData.push(row);
    });

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(wsData);

    // Set column widths
    const colWidths = [{ wch: 15 }, ...days.map(() => ({ wch: 30 }))];
    ws['!cols'] = colWidths;

    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Timetable');

    // Save file
    XLSX.writeFile(wb, 'timetable.xlsx');
  };

  return (
    <div className="flex gap-3">
      <Button
        onClick={exportToPDF}
        variant="outline"
        className="gap-2"
      >
        <Download className="h-4 w-4" />
        Export to PDF
      </Button>
      <Button
        onClick={exportToExcel}
        variant="outline"
        className="gap-2"
      >
        <FileSpreadsheet className="h-4 w-4" />
        Export to Excel
      </Button>
    </div>
  );
};

export default ExportButtons;
