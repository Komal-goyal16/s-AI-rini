import { 
  LayoutDashboard, 
  BookOpen, 
  Users, 
  UsersRound, 
  DoorOpen, 
  Clock, 
  Calendar,
  LogOut,
  Settings
} from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
} from '@/components/ui/sidebar';

export function AppSidebar() {
  const { role, signOut } = useAuth();

  const adminItems = [
    { title: 'Dashboard', url: '/admin', icon: LayoutDashboard },
    { title: 'Courses', url: '/admin/courses', icon: BookOpen },
    { title: 'Faculty', url: '/admin/faculty', icon: Users },
    { title: 'Student Groups', url: '/admin/students', icon: UsersRound },
    { title: 'Rooms', url: '/admin/rooms', icon: DoorOpen },
    { title: 'Time Slots', url: '/admin/timeslots', icon: Clock },
    { title: 'Timetable', url: '/admin/timetable', icon: Calendar },
  ];

  const facultyItems = [
    { title: 'My Schedule', url: '/faculty', icon: Calendar },
  ];

  const studentItems = [
    { title: 'My Timetable', url: '/student', icon: Calendar },
  ];

  const items = role === 'admin' ? adminItems : role === 'faculty' ? facultyItems : studentItems;

  // Ensure non-active items use text-foreground for proper contrast
  const getNavCls = ({ isActive }: { isActive: boolean }) =>
    isActive
      ? 'bg-accent text-accent-foreground font-medium'
      : 'hover:bg-accent/50 text-foreground';

  return (
    <Sidebar>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-foreground">
            {role === 'admin' ? 'Administration' : role === 'faculty' ? 'Faculty Portal' : 'Student Portal'}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild tooltip={item.title}>
                    <NavLink to={item.url} end className={getNavCls}>
                      <item.icon className="h-4 w-4 shrink-0" />
                      <span>{item.title}</span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      
      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton onClick={() => signOut()} tooltip="Sign Out" className="text-foreground">
              <LogOut className="h-4 w-4 shrink-0" />
              <span>Sign Out</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
