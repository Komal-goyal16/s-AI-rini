import { Card } from "@/components/ui/card";
import { Edit } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TimetableEntry {
  course_code: string;
  course_name: string;
  faculty_name: string;
  room_number: string;
  day: string;
  time: string;
}

interface TimetableGridProps {
  entries: TimetableEntry[];
  onEditEntry?: (entry: TimetableEntry) => void;
  editable?: boolean;
}

const TimetableGrid = ({ entries, onEditEntry, editable = false }: TimetableGridProps) => {
  // Get unique days and times
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const times = Array.from(new Set(entries.map(e => e.time))).sort();

  // Create a lookup map for quick access
  const entryMap = new Map<string, TimetableEntry>();
  entries.forEach(entry => {
    const key = `${entry.day}-${entry.time}`;
    entryMap.set(key, entry);
  });

  return (
    <div className="overflow-x-auto">
      <div className="min-w-[800px]">
        {/* Header */}
        <div className="grid grid-cols-7 gap-2 mb-2">
          <div className="font-semibold text-sm text-muted-foreground p-2">
            Time
          </div>
          {days.map(day => (
            <div
              key={day}
              className="font-semibold text-sm text-center p-2 bg-primary/10 rounded-md"
            >
              {day}
            </div>
          ))}
        </div>

        {/* Time slots */}
        {times.map(time => (
          <div key={time} className="grid grid-cols-7 gap-2 mb-2">
            <div className="flex items-center justify-center text-sm font-medium text-muted-foreground p-2 bg-secondary rounded-md">
              {time}
            </div>
            {days.map(day => {
              const entry = entryMap.get(`${day}-${time}`);
              
              return (
                <Card
                  key={`${day}-${time}`}
                  className={`p-3 transition-all hover:shadow-md relative group ${
                    entry
                      ? 'bg-gradient-to-br from-card to-card/80 border-primary/20'
                      : 'bg-muted/30 border-dashed'
                  }`}
                >
                  {entry ? (
                    <>
                      <div className="space-y-1">
                        <div className="font-semibold text-sm text-primary">
                          {entry.course_code}
                        </div>
                        <div className="text-xs text-foreground/80 line-clamp-1">
                          {entry.course_name}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {entry.faculty_name}
                        </div>
                        <div className="text-xs font-medium text-accent">
                          {entry.room_number}
                        </div>
                      </div>
                      {editable && onEditEntry && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => onEditEntry(entry)}
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                      )}
                    </>
                  ) : (
                    <div className="text-xs text-muted-foreground text-center">
                      Free
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};

export default TimetableGrid;
