import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";

interface EditEntryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  entry: {
    course_code: string;
    course_name: string;
    faculty_name: string;
    room_number: string;
    day: string;
    time: string;
  } | null;
  availableFaculty: Array<{ id: string; name: string; expertise_course_codes: string[] }>;
  availableRooms: Array<{ id: string; room_number: string; room_type: string }>;
  availableTimeSlots: Array<{ id: string; day_of_week: string; start_time: string; end_time: string }>;
  onSave: (updates: {
    oldEntry: any;
    newFacultyId: string;
    newRoomId: string;
    newTimeSlotId: string;
  }) => Promise<void>;
}

const EditEntryDialog = ({
  open,
  onOpenChange,
  entry,
  availableFaculty,
  availableRooms,
  availableTimeSlots,
  onSave,
}: EditEntryDialogProps) => {
  const [selectedFacultyId, setSelectedFacultyId] = useState<string>("");
  const [selectedRoomId, setSelectedRoomId] = useState<string>("");
  const [selectedTimeSlotId, setSelectedTimeSlotId] = useState<string>("");
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (entry && open) {
      // Find matching IDs based on current entry
      const faculty = availableFaculty.find(f => f.name === entry.faculty_name);
      const room = availableRooms.find(r => r.room_number === entry.room_number);
      const timeSlot = availableTimeSlots.find(
        ts => ts.day_of_week === entry.day && 
        `${ts.start_time} - ${ts.end_time}` === entry.time
      );

      setSelectedFacultyId(faculty?.id || "");
      setSelectedRoomId(room?.id || "");
      setSelectedTimeSlotId(timeSlot?.id || "");
    }
  }, [entry, open, availableFaculty, availableRooms, availableTimeSlots]);

  const handleSave = async () => {
    if (!entry || !selectedFacultyId || !selectedRoomId || !selectedTimeSlotId) return;

    setIsSaving(true);
    try {
      await onSave({
        oldEntry: entry,
        newFacultyId: selectedFacultyId,
        newRoomId: selectedRoomId,
        newTimeSlotId: selectedTimeSlotId,
      });
      onOpenChange(false);
    } catch (error) {
      console.error('Error saving changes:', error);
    } finally {
      setIsSaving(false);
    }
  };

  if (!entry) return null;

  // Filter faculty by expertise
  const compatibleFaculty = availableFaculty.filter(f => 
    f.expertise_course_codes.includes(entry.course_code)
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Edit Class Schedule</DialogTitle>
          <DialogDescription>
            Modify the assignment for <span className="font-semibold text-primary">{entry.course_code} - {entry.course_name}</span>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="faculty">Faculty</Label>
            <Select value={selectedFacultyId} onValueChange={setSelectedFacultyId}>
              <SelectTrigger id="faculty">
                <SelectValue placeholder="Select faculty" />
              </SelectTrigger>
              <SelectContent>
                {compatibleFaculty.map(faculty => (
                  <SelectItem key={faculty.id} value={faculty.id}>
                    {faculty.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {compatibleFaculty.length === 0 && (
              <p className="text-xs text-destructive">No faculty with required expertise available</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="room">Room</Label>
            <Select value={selectedRoomId} onValueChange={setSelectedRoomId}>
              <SelectTrigger id="room">
                <SelectValue placeholder="Select room" />
              </SelectTrigger>
              <SelectContent>
                {availableRooms.map(room => (
                  <SelectItem key={room.id} value={room.id}>
                    {room.room_number} ({room.room_type})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="timeslot">Time Slot</Label>
            <Select value={selectedTimeSlotId} onValueChange={setSelectedTimeSlotId}>
              <SelectTrigger id="timeslot">
                <SelectValue placeholder="Select time slot" />
              </SelectTrigger>
              <SelectContent>
                {availableTimeSlots.map(slot => (
                  <SelectItem key={slot.id} value={slot.id}>
                    {slot.day_of_week} {slot.start_time} - {slot.end_time}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleSave} 
            disabled={isSaving || !selectedFacultyId || !selectedRoomId || !selectedTimeSlotId}
          >
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              'Save Changes'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default EditEntryDialog;
